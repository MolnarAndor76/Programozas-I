#include<iostream>
#include<iomanip>
#include <string>
using namespace std;
// Adott egy 5 dolgoz�b�l �ll� brigad. T�roljuk a dolgoz�k nev�t �s fizet�s�t.
// K�rj�k be az adatokat, �rjuk ki t�bl�zatosan �s sz�moljuk ki az �ssz. fizet�st!
// Haszn�ljunk a nevek t�rol�s�ra string tipust!
struct dolgozo
{
	string nev;
	int fiz;
};

int main()
{
	dolgozo csop[5];
	int i, ossz = 0;

	// dolgoz�i adatok bek�r�se
	for (i = 0; i < 5; i++)
	{
		cout << "Adja meg a(z) " << i + 1 << ". dolgozo nevet: ";
		getline(cin, csop[i].nev);
		cout << "Adja meg a fizeteset: ";
		cin >> csop[i].fiz;
		cin.ignore();
	}		//mivel ez ut�n ism�t getline vegy�k ki a billenty�zet pufferb�l a sorv�g(ENTER) jelet
	system("cls");                			//k�perny� t�rl�s

	// kiiratas tablazatosan + osszfizetes szamitas
	cout.setf(ios::left);       			 // balra z�rt ki�r�s
	for (i = 0;i < 5;i++)
	{
		cout << setw(25) << csop[i].nev << "\t" << csop[i].fiz << endl;
		ossz = ossz + csop[i].fiz;
	}
	cout << "\nA csoport osszfizetese: " << ossz << endl;
	return 0;
}
