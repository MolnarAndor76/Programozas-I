// Kock�val dobunk 1000-szer(1-6). T�lts�k az egyes dob�sok eredm�ny�t a kocka[] t�mbbe!
// Az egyes dob�sok eredm�ny�t v�letlengener�torral adjuk meg!
// Sz�moljuk meg hogy az egyes dob�sokb�l h�ny db volt ( MEGSZ�ML�L�S t�tele) �s �rassuk ki!
// Sz�moljuk meg h�ny db p�ros dob�s volt!

#include <ctime>
#include <iostream>
using namespace std;

int main()
{
	int kocka[1000], TAR[6] = { 0 }, i; // A TAR[] -ban sz�moljuk, hogy az egyes dob�sokb�l mennyi volt
	
	//dob�s bek�r�se v�letlen gener�torral
	
	srand((unsigned int)time(NULL));
	for (i = 0;i < 1000;i++)           
	{
		kocka[i] = rand() % 6 + 1;
		cout << kocka[i] << " ";
	}

	int dbparos = 0;
	// eredm�nyek megsz�ml�l�sa, p�ros dob�sok sz�ma 
	for (i = 0;i < 1000;i++)              
	{
		switch (kocka[i])			// helyette TAR[kocka[i]-1]
		{
		case 1: TAR[0]++; break;
		case 2: TAR[1]++; break;
		case 3: TAR[2]++; break;
		case 4: TAR[3]++; break;
		case 5: TAR[4]++; break;
		case 6: TAR[5]++; break;
		}
		if (kocka[i] % 2 == 0)
		{
			dbparos++;
		}
	}
	// eredm�nyek ki�rat�sa         
	cout << endl;
	for (i = 0;i < 6;i++)                  
	{
		cout << "\nA(z) " << i + 1 << "-es dobasok szama:\t" << TAR[i];
	}
	cout << "\nA(z) paros dobasok szama:\t" << dbparos << endl;
	return 0;
}
