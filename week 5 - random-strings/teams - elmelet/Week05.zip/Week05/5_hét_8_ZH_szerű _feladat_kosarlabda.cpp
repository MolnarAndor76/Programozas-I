/* Egy max 12 f�s kos�rlabda csapat adatait t�roljuk egy strukt�ra t�mbben.
* T�roljuk a j�t�kosok nev�t, magass�g�t, �s dobott pontjait.
* 1, K�rj�k be ellen�rz�tten a csapat l�tsz�m�t (5-12)!
* 2, T�lts�k fel a strukt�rat�mb�t adatokkal �gy, hogy a nevet billenty�zetr�l k�rj�k be,
* a magass�got �s pontokat v�letlengener�torral �ll�tsuk el�. A magass�g 170- 220 cm, a dobott pontok
* 0-100 k�z�tt lehetnek.
* 3,�rassuk ki az adatokat t�bl�zatosan!
* 4, Sz�m�tsuk ki a csapat pont �tlag�t!
* 5, Ki a legmagasabb (adjuk meg a nev�t)!
* 6, Sz�moljuk meg h�nyan dobtak 50 pont felett!
*
*/
#include<iostream>
#include<string>
#include<ctime>
using namespace std;
struct kosar
{
	string nev;
	int magassag;
	int pont;
};
int main()
{
	int letszam;
	//1, L�tsz�m ellen�rz�tt bek�r�se
	do
	{
		cout<<"Adja meg a letszamot 5-12 kozott!"<<endl;
		cin >> letszam;
	} while (letszam > 12 || letszam < 5);
	cin.ignore();// a k�s�bbi getline() miatt kell

	//2,  Csapat adatainak bek�r�se
	kosar csapat[12]; 
	srand((unsigned int)time(NULL));
	for (int i = 0; i < letszam; i++)
	{
		cout<<"Adja meg az "<<i+1<<". jatekos nevet:"<<endl;
		getline(cin,csapat[i].nev);
		csapat[i].magassag = rand()%51+170;
		csapat[i].pont = rand()%101;
		// nincs sz�ks�g az ignore() haszn�lat�ra mert nem haszn�lunk cin -t.
	}
	
	//3, Csapattagok adatainak t�bl�zatos ki�rat�sa // nem form�zott ki�r�s
	system("CLS");
	for (int i = 0; i < letszam; i++)
	{
		cout<<csapat[i].nev<<" "<< csapat[i].magassag<<" "<<csapat[i].pont<<endl;
	}
	
	//4, Sz�m�tsuk ki a csapat pont �tlag�t!
	float atl = 0;
	for (int i = 0; i < letszam; i++)
	{
		atl = atl + csapat[i].pont;
	}
	cout<<"A csapat pontatlaga: "<<atl / letszam<<endl;
	
	//5, Legmagasabb jatekos neve
	int max = 0;
	for (int i = 1; i < letszam; i++)
	{
		if (csapat[i].magassag > csapat[max].magassag) { max = i; }
	}
	cout<<"A legmagasabb jatekos neve: "<<csapat[max].nev<<endl;

	//6, Az �tven pont felett dob�k sz�ma
	int db50 = 0;
	for (int i = 0; i < letszam; i++)
	{
		if (csapat[i].pont > 50)
		{
			db50++;
		}
	}
	cout<<"Az otven pont felett dobok szama: "<<db50<<endl;
	return 0;
}