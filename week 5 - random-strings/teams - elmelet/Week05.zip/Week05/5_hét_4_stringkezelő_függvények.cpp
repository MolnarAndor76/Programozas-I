# include <iostream>
# include <string> 
// Feladat a stringkezel� f�ggv�nyek gyakorl�s�ra
using namespace std;
int main()
{
	string szo; 			// szo n�ven �res objektum l�trehoz�sa 
	szo = "Ez egy szoveg elso sora.";
	cout << "A szoveg hossza bajtban :" << szo.size()<<endl;   // string m�rete
	string szo2=" Ez a masodik";
	cout << szo + " " + szo2 << endl;  // + m�velet az �sszef�z�s a stringeken
	
	string s2 = szo; //vagy s2(s)
	int hol=s2.find("elso");		// visszaadja hol kezd�dik az s2 ben az "elso" string 
	cout << "hol= " << hol << endl; 
		
	string szoveg = " Eg a napmelegtol a kopar szik sarja";
	if (szoveg.find("tarja") == string::npos)  // ha nincs a "tarja" string a szoveg stringben
												// string::npos �rt�ke 4294967295 - a legnagyobb uintn�l 1-gyel nagyobb
		
		cout << " Nincs a tarja szo a szovegben" <<  endl;

	s2.replace(hol, 4, "masodik"); // cser�l mett�l meddig mire
	cout << "s2= " << s2 << endl;
	
	hol= s2.find("egy");
	cout << "hol= " << hol << endl;

	string t2=s2.erase(hol, 4); // torol mett�l meddig
	cout << "t2= " << t2 << endl;
	
	hol = s2.find("szoveg");
	cout << "hol= " << hol << endl;
	s2.insert(hol, "a ");			// besz�r hova mit
	cout << "s2= " << s2 << endl;
	
	s2 += " - az elso atalakitva";
	cout << "s2= " << s2 << endl;
    
	cout<<t2.substr(5,t2.size())<<endl;   // r�szsztirng k�pz�s az 5. b�jtt�l a v�g�ig
return 0;
}
