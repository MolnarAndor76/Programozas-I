#include<iostream>
#include<iomanip>
#include<string>
using namespace std;
// Egy hallgat�i csoportba max. 15-en j�rhatnak.T�roljuk a hallgat�k nev�t, jegy�t �s a sz�let�si �v�t!
//K�rj�k be a val�s csoportl�tsz�mot ellen�rz�tten, majd a hallgat�i adatokat!
//�rassuk ki az adatokat t�bl�zatosan, sz�m�tsuk ki a csoport �tlag�t, majd �rassuk ki a leg�regebb hallgat� nev�t!
struct tanulo
{
	string nev;
	int jegy;
	int szul;
};
int main()
{
	tanulo hallg[15];
	int letszam, i, atlag = 0;

	// l�tszam�m bek�r�se ellen�rz�tten
	do
	{
		cout << "Adja meg a csoport letszamamot (1-15 kozott): ";
		cin >> letszam;
		cin.ignore();
	} while (letszam < 1 || letszam>15);

	// hallgat�i adatok ellen�rz�tten
	for (i = 0;i < letszam;i++)
	{
		cout << "Adja meg a(z) " << i + 1 << ". tanulo nevet: ";
		getline(cin, hallg[i].nev);
		cout << "Adja meg a szul evszamot: ";
		cin >> hallg[i].szul;
		do
		{
			cout << "Adja meg a jegyet: ";
			cin >> hallg[i].jegy;
			cin.ignore();
		} while (hallg[i].jegy < 1 || hallg[i].jegy > 5);
	}

	system("cls");                					//k�perny� t�rl�s

	// kiiratas tablazatosan + atlagszamitas

	cout.setf(ios::left);
	cout << "Adatok: " << endl;
	cout << setw(10) << "Nev:" << "\t" << "Jegy:" << "\t" << "Szuletesi ev:" << endl;
	for (i = 0;i < letszam;i++)
	{
		cout << setw(10) << hallg[i].nev << "\t" << hallg[i].jegy << "\t" << hallg[i].szul << endl;
		atlag += hallg[i].jegy;
	}
	cout << "\nA csoport atlaga: " << (float)atlag / letszam << endl;

	// leg�regebb tanulo - min kivalasztas
	int legoregebb = 0;			// legyen az els� tanul� a leg�regebb
	for (i = 1;i<letszam;i++)
	{
		if (hallg[legoregebb].szul>hallg[i].szul)
		{
			legoregebb = i;							// a leg�regebb az i. hallgat�
		}
	}
	cout << "\nA legoregebb hallgato neve: " << hallg[legoregebb].nev << endl;
	return 0;
}
