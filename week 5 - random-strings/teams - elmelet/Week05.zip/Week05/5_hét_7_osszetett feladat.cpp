/*Feladat :
Egy vegyesbolt adatait kell t�rolni. T�roljuk az �ruk neveit (string),  �r�t, 
�s a rakt�ron l�v� darabsz�mot!
Hozzunk l�tre egy az el�bbiek t�rol�s�ra szolg�l� strukt�ra t�pus� v�ltoz�t!
Maximum 15 db k�l�nf�le �r�nk lehet (15 elem� a strukt�ra t�mb)!     
1. K�rj�k  be az �r�k sz�m�t ellen�rz�tten!
2. K�rj�k be az �ruk neveit! (pl. fekete ribizli sz�rp)
3. K�rj�k be az �ruk �r�t ellen�rz�tten(nem lehet 5000 Ft n�l nagyobb �s 100 Ft- n�l kisebb!)    
4. Tal�lja ki a darabsz�mokat v�letlengener�torral (1 �s 10 db k�z�tt lehet)   
5. �rja ki az adatokat t�bl�zatosan!   
6. Hat�rozza meg, �s �rja ki, mennyi az eg�sz �ruk�szlet �rt�ke!
7. Sz�molja ki az �tlagos �rat �s �rja ki a k�perny�re !
8. Sz�molja meg h�ny �rub�l van t�bb mint �t rakt�rk�szleten!
9. �rja ki a legdr�g�bb �ru nev�t �s �r�t!
10. Emelje az �rakat 20 %-kal majd �rja ki az �ruk nev�t �s �j �r�t! 
*/
#include <iostream>
#include<iomanip>
#include<string>
#include<ctime>
using namespace std;

struct Aru
{
	string arunev;
	int ar;
	int db;
};
int main()
{
	Aru bolt[15];
	int i, legdragabb, ertek = 0, atlagar = 0, aruszam;
	srand((unsigned)time(NULL));
	// adatbek�r�s - k�l�nb�z� �ruk darabsz�m�nak bek�r�se ellen�rz�tten
	do 
	{
		cout << "Adja meg hanyfele aru van a boltban ! (1-15)" << endl;
		cin >> aruszam;
		cin.ignore();
		if (aruszam < 1 || aruszam>15) cout << "Hibas adat, az aruk szama 1-15 lehet!" << endl;
	} while (aruszam < 1 || aruszam>15);
	
	// adatbek�r�s - k�l�nb�z� �ruk neve, darabsz�ma �s �ra
	for (i = 0; i <aruszam; i++)
	{
		cout << "Adja meg az " << i + 1 << " . aru nevet\n";
		getline(cin, bolt[i].arunev);						//  aru nev�nek bek�r�se
		do
		{
			cout << "Adja meg az aru arat ( 100-5000Ft)\n";	// �r ellen�rz�tt bek�r�se 100FT �s 5000 k�z�tt!
			cin >> bolt[i].ar;
			cin.ignore();
			if (bolt[i].ar < 100 || bolt[i].ar>5000) cout << "Hibas adat, az aruk ara 100-1850 FT lehet!" << endl;
		} while (bolt[i].ar < 100 || bolt[i].ar>5000);
		
		bolt[i].db = rand() % 10 + 1;			// darabsz�m bek�r�se v�letlen gener�torral 1-10
	
	}
	// 5. feladat eredmenyek kiiraatasa "tablazatosan"
	system("cls");			// k�perny� t�rl�s
	cout.setf(ios::left);	// balra igaz�tott ki�r�s

	for (i = 0; i <aruszam; i++) // adatok t�bl�zatosan
	{
		cout << setw(20) << bolt[i].arunev <<setw(6)<<bolt[i].ar<<"Ft" << "\t" << bolt[i].db <<" db" <<endl;
	}
	
	// 6. feladat adatok feldolgoz�sa - eg�sz �ruk�szlet �rt�ke

	for (i = 0; i < aruszam; i++)
	{
		ertek = ertek+ bolt[i].ar * bolt[i].db;
	}
	cout << "Az arukeszlet ossz ereteke: " << ertek << endl;

	// 7. feladat adatok feldolgoz�sa - �tlag�r 
	for (i = 0; i < aruszam; i++)
	{
		atlagar = atlagar + bolt[i].ar;
	}
	cout << "Az aruk atlagara :" << atlagar / aruszam << endl; //(nincs sz�ks�g a t�rtr�szre)
	
	// 8. feladat adatok feldolgoz�sa - h�ny �rub�l van t�bb mint �t rakt�rk�szleten!
	
	int otneltobb = 0;
	for (i = 0; i < aruszam; i++)
	{
		if( bolt[i].db>5)
		{
		otneltobb++;
		};
	}
	cout << otneltobb << " arubol van otnel tobb a keszleten " << endl;
	
	//9. feladat adatok feldolgoz�sa - �rja ki a legdr�g�bb �ru nev�t �s �r�t!
	legdragabb = 0;										// legyen a 0. �ru a legdr�g�bb
	for (i = 1; i < aruszam; i++)
	{
		if (bolt[i].ar > bolt[legdragabb].ar) legdragabb = i;   // jegyezz�k meg a lagdragabb aru sorszamat
	}
	cout<<"A legdragabb aru adatai: \n"<<setw(20) << bolt[legdragabb].arunev << bolt[legdragabb].ar << "\t" << bolt[legdragabb].ar << endl;
	
	//10. feladat Emelje az �rakat 20 %-kal majd �rja ki az �ruk nev�t �s �j �r�t! 
	
	cout << "Az aruk adatai 20%-os emeles utan :" << endl;
	for (i = 0; i < aruszam; i++)
	{
		bolt[i].ar = bolt[i].ar*1.2;    // 20%-os emel�s
		cout << setw(20) << bolt[i].arunev << setw(6) << bolt[i].ar << "Ft" << "\t" << bolt[i].db << " db" << endl;
	}
	return 0;
}
