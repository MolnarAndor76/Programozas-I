// Sting t�pus haszn�lata, getline() - stringek eset�ben. 
//K�rj�nk be egy nevet a billenty�zetr�l, valamint egy sz�mot,
// majd �rjuk ki az adott nevet a k�perny�re a bek�rt "sz�mszor"!
#include <iostream>
#include <string>
using namespace std;
int main()
{
	int hanyszor;
	cout << "Hanyszor irjuk ki a kepernyore ?" << endl;
	cin >> hanyszor;
	cin.ignore();
	string nev;
	cout << "Adja meg a nevet" << endl;
	getline(cin, nev);
	
	for (int i = 0; i < hanyszor; i++)
	{
		cout << nev << endl;
	}
	return 0;
}

