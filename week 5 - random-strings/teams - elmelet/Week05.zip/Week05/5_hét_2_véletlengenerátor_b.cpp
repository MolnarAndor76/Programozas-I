// K�t kock�val dobunk 100-szer (2-12). T�lts�k az egyes dob�sok eredm�ny�t a kocka[] t�mbbe!
// Az egyes dob�sok eredm�ny�t v�letlengener�torral adjuk meg!
// Sz�moljuk meg hogy a p�ros vagy a p�ratlan dob�sokb�l volt-e t�bb!

#include <ctime>
#include <iostream>
using namespace std;

int main()
{
	int kocka[100], DB_paros=0, i; // el�g a p�rosakat sz�molni
	
	//dob�s bek�r�se v�letlen gener�torral
	
	srand((unsigned int)time(NULL));
	for (i = 0;i < 100;i++)           
	{
		kocka[i] = rand()% 11  + 2;
		cout << kocka[i] << " ";
		if (kocka[i] % 2 == 0)
		{
			DB_paros++;
		}
	}
	// eredm�ny ki�rat�sa  
	if (DB_paros == 50)cout << "\nEgyforma szamu paros es paratlan" << endl;
	else
		if (100 - DB_paros > 50) cout << "\nParatlanbol volt tobb" << endl;
		else cout << "\nParosbol volt tobb" << endl;
	return 0;
}
