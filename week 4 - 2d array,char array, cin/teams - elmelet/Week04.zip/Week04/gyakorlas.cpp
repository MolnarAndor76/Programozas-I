#include <iostream>
using namespace std;

struct Hallgato
{
    char nev[50];
    int szulEv;
    int jegy;
};

int main()
{
    Hallgato hallgatok[10];

    int letszam;

    // Hallgatok szamanak bekerese
    do
    {
        cout << "Hany hallgato adatait szeretne megadni? (1-10): ";
        cin >> letszam;
        cin.ignore();

        if (letszam < 1 || letszam > 10)
        {
            cout << "Hibas letszam! 1 es 10 kozotti erteket adjon meg."
                 << endl;
        }

    } while (letszam < 1 || letszam > 10);
    
    // Hallgatok adatainak bekerese
    for (int i = 0; i < letszam; i++)
    {
        cout << endl;
        cout << i + 1 << ". hallgato adatai" << endl;

        cout << "Nev: ";
        cin.getline(hallgatok[i].nev, 50);

        cout << "Szuletesi ev: ";
        cin >> hallgatok[i].szulEv;

        // Jegy ellenorzott bekerese
        do
        {
            cout << "Jegy (1-5): ";
            cin >> hallgatok[i].jegy;

            if (hallgatok[i].jegy < 1 ||
                hallgatok[i].jegy > 5)
            {
                cout << "Hibas jegy! 1 es 5 kozotti erteket adjon meg."
                     << endl;
            }

        } while (hallgatok[i].jegy < 1 ||
                 hallgatok[i].jegy > 5);

        // A kovetkezo getline() elott el kell dobni az ENTER-t
        cin.ignore();
    }

    // Adatok kiirasa
    cout << endl;
    cout << "---------------------------------------------" << endl;
    cout << "Hallgatok adatai" << endl;
    cout << "---------------------------------------------" << endl;

    for (int i = 0; i < letszam; i++)
    {
        cout << "Nev: " << hallgatok[i].nev << endl;
        cout << "Szuletesi ev: " << hallgatok[i].szulEv << endl;
        cout << "Jegy: " << hallgatok[i].jegy << endl;
        cout << "---------------------------------------------" << endl;
    }

    // Atlag kiszamitasa
    int osszeg = 0;

    for (int i = 0; i < letszam; i++)
    {
        osszeg = osszeg + hallgatok[i].jegy;
    }

    double atlag = (double)osszeg / letszam;

    cout << "Atlagos jegy: " << atlag << endl;

    // Legjobb es legrosszabb jegy megkeresese
    int legjobbJegy = hallgatok[0].jegy;
    int legrosszabbJegy = hallgatok[0].jegy;

    int legjobbIndex = 0;
    int legrosszabbIndex = 0;

    for (int i = 1; i < letszam; i++)
    {
        if (hallgatok[i].jegy > legjobbJegy)
        {
            legjobbJegy = hallgatok[i].jegy;
            legjobbIndex = i;
        }

        if (hallgatok[i].jegy < legrosszabbJegy)
        {
            legrosszabbJegy = hallgatok[i].jegy;
            legrosszabbIndex = i;
        }
    }

    cout << endl;
    cout << "Legjobb jegy: "
         << legjobbJegy << endl;

    cout << "Legjobb hallgato: "
         << hallgatok[legjobbIndex].nev << endl;

    cout << endl;

    cout << "Legrosszabb jegy: "
         << legrosszabbJegy << endl;

    cout << "Legrosszabb hallgato: "
         << hallgatok[legrosszabbIndex].nev << endl;

    // Otosok megszamlalasa
    int otosok = 0;

    for (int i = 0; i < letszam; i++)
    {
        if (hallgatok[i].jegy == 5)
        {
            otosok++;
        }
    }

    cout << endl;
    cout << "Otost szerzett hallgatok szama: "
         << otosok << endl;

    return 0;
}