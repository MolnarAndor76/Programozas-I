#include <iostream>
#include <cstring>
#include <cctype>

using namespace std;

int main()
{
    char szoveg[100];

    cout << "Adjon meg egy szoveget: ";
    cin.getline(szoveg, 100);

    cout << "\nEredeti szoveg: ";
    cout << szoveg << endl;

    cout << "Hossza: "
         << strlen(szoveg) << endl;

    cout << "Nagybetusen: ";

    for (int i = 0; i < strlen(szoveg); i++)
    {
        cout << (char)toupper(szoveg[i]);
    }

    cout << endl;

    return 0;
}