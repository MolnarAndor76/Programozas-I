#include <iostream>
using namespace std;

int main()
{
    int kor;
    char nev[50];

    cout << "Kor: ";
    cin >> kor;

    cout << "Nev: ";
    cin.getline(nev, 50);

    cout << "Nev: " << nev << endl;

    return 0;
}