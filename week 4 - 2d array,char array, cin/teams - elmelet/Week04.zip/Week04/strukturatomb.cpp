#include <iostream>
using namespace std;

struct Tanulo
{
    char nev[50];
    int jegy;
    int szulEv;
};

int main()
{
    Tanulo hallgatok[5];

    // Adatok bekérése
    for (int i = 0; i < 5; i++)
    {
        cout << "\n" << i + 1 << ". hallgato\n";

        cout << "Nev: ";
        cin.getline(hallgatok[i].nev, 50);

        cout << "Szuletesi ev: ";
        cin >> hallgatok[i].szulEv;

        cout << "Jegy: ";
        cin >> hallgatok[i].jegy;

        cin.ignore();
    }

    // Adatok kiírása
    cout << "\nHallgatok:\n";

    for (int i = 0; i < 5; i++)
    {
        cout << hallgatok[i].nev
             << " - "
             << hallgatok[i].szulEv
             << " - "
             << hallgatok[i].jegy
             << endl;
    }

    return 0;
}