#include <iostream>
using namespace std;

int main()
{
    int hom[4][7];

    // Feltöltés
    for (int i = 0; i < 4; i++)
    {
        cout << i + 1 << ". het\n";

        for (int j = 0; j < 7; j++)
        {
            cout << j + 1 << ". nap: ";
            cin >> hom[i][j];
        }
    }

    // Kiírás
    cout << "\nHomersegletek:\n";

    for (int i = 0; i < 4; i++)
    {
        for (int j = 0; j < 7; j++)
        {
            cout << hom[i][j] << "\t";
        }

        cout << endl;
    }

    return 0;
}