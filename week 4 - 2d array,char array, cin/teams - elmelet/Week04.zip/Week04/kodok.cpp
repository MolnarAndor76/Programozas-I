int homerseklet[7];

homerseklet[0] = 23;
homerseklet[1] = 25;