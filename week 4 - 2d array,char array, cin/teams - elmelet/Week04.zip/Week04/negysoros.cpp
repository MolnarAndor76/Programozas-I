#include <iostream>
#include <cstring>
#include <cctype>

using namespace std;

int main()
{
    char sorok[4][100];

    for (int i = 0; i < 4; i++)
    {
        cout << i + 1 << ". sor: ";
        cin.getline(sorok[i], 100);
    }

    cout << "\nNagybetus szoveg:\n";

    for (int i = 0; i < 4; i++)
    {
        for (int j = 0; j < strlen(sorok[i]); j++)
        {
            sorok[i][j] = (char)toupper(sorok[i][j]);
        }

        cout << sorok[i] << endl;
    }

    return 0;
}