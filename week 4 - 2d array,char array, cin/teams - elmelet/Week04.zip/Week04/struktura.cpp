#include <iostream>
using namespace std;

struct Tanulo
{
    char nev[50];
    int jegy;
    int kredit;
};

int main()
{
    Tanulo t;

    cout << "Nev: ";
    cin.getline(t.nev, 50);

    cout << "Jegy: ";
    cin >> t.jegy;

    cout << "Kredit: ";
    cin >> t.kredit;

    cout << "\nA hallgato adatai:\n";
    cout << "Nev: " << t.nev << endl;
    cout << "Jegy: " << t.jegy << endl;
    cout << "Kredit: " << t.kredit << endl;

    return 0;
}