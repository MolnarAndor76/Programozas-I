#include <iostream>
using namespace std;
int main()
{
    double arfolyam;
    double euro;
    int forint;
    cout << "Kerem az aktualis euro arfolyamot (pl.: 410.5): ";
    cin >> arfolyam;
    cout << "Hany eurot szeretne atvaltani?: ";
    cin >> euro;
    forint = euro * arfolyam;
    cout << "\n--- Valutavalto ---" << endl;
    cout << euro << " EUR erteke: " << forint << " HUF." << endl;
    return 0;
}
