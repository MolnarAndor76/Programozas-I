#include <iostream>
using namespace std;
int main()
{
	int hossz;
	hossz = 15;
	cout << "A negyzet kerulete:";
	cout << 4 * hossz << "cm" << endl;	//rövidebben: cout <<"A negyzet kerulete:"<< 4*hossz<<"cm\n";
	return 0;
}
