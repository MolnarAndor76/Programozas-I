#include <iostream>
using namespace std;
int main()
{
	int r = 8;
	cout << "A kor kerulete: " << (float)(2 * r * 3.14) << "cm\n";
	cout << "A kor terulete: " << (float)(r * r * 3.14) << "cm2" << endl;
	return 0;
}
