#include <iostream>
using namespace std;
int main()
{
    int ido, ora, perc, mp;
    cout << "Adja meg az idot masodpercekben: ";
    cin >> ido;
    ora = ido / 3600;        // 1 óra = 3600 másodperc
    mp = ido % 3600;        // A megmaradt másodpercek az órák után
    perc = mp / 60;         // A megmaradt másodpercekből hány perc jön ki
    mp = mp % 60;           // A végül megmaradt tiszta másodpercek
    cout << "A megadott idő ";
    cout << ora << " ora, " << perc << " perc es " << mp << " masodperc." << endl;
    return 0;
}