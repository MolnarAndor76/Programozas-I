#include <iostream>
using namespace std;
int main()
{
	int a = 8, b = 4;
	cout << "a + b: " << a + b << endl; //12
	cout << "a - b: " << a - b << endl; //4
	cout << "a * b: " << a * b << endl; //32
	cout << "a / b: " << a / b << endl; //2
	cout << "a % b: " << a % b << endl; //0
	return 0;
}
