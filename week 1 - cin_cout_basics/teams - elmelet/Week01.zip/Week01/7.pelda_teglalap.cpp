#include <iostream>
using namespace std;
int main()
{
	int a, b;
	cout << "Adja meg a teglalap oldalainak hosszat:  \n";
	cin >> a >> b;;
	cout << "A teglalap kerulete: " << 2 * (a + b) << "cm" << endl;
	cout << "A teglalap terulete: " << a * b << "cm2" << endl;
	return 0;
}
