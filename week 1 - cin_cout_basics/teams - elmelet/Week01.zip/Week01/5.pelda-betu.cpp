#include <iostream>
using namespace std;
int main()
{
    int i;
    char betu = 'z';    //karakter megadás '' között
    i = betu;           //az i szám típusú változó értéke az adott betű ASCII kódja lesz
    cout << "A betu szamkent: " << i << ", karakterkent: " << betu << endl;
    return 0;
}
