#include <iostream>
using namespace std;
int main()
{
	int r = 15, k, t;		//r változó deklarálása, k és t változó definiálása
	k = 2 * r * 3.14;
	t = r * r * 3.14;
	cout << "Az " << r << "cm sugaru kor kerulete: " << k << "cm, terulete 		pedig: " << t << "cm2" << endl;
	//a kiíratásnál nem jelenik meg a k és t értékénél a tizedes rész, mert az int típus miatt csonkolja
	return 0;
}
