#include<iostream>
using namespace std;

int main()
{
	double sz1,sz2;
	char mjel;
	cout << "\n\tSzamolpgep\n\n";
	cout << "\tadajon meg egy szamot ";
	cin >> sz1;
	cout << "\tadajon meg egy masik szamot ";
	cin >> sz2;
	cout << "\tadajon meg egy muveleti jelet( + - * / ) ";
	cin >> mjel;
	if (sz2 == 0 and mjel == '/' )
	{
		cout << "\na 0-val valo osztast nem ertelmezzuk!!!";
		return 0;
	}
	cout <<"\n\teredmeny:\n";
	cout << "\t\t" << sz1 << " " << mjel << " " << sz2 << " = ";
	switch (mjel)
	{
	case '+':
		cout << sz1 + sz2 << endl;
		break;
	case '-':
		cout << sz1 - sz2 << endl;
		break;
	case '*':
		cout << sz1 * sz2 << endl;
		break;
	case '/':
		cout << sz1 / sz2 << endl;
		break;
	default:
		cout << "hibas adatok" << endl;
	}
	return 0;
}

