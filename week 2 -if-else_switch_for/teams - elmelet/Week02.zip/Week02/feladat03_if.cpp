#include <iostream>

using namespace std;

int main()
{
    double szam;
    cout << "Adj meg egy szamot: ";
    cin >> szam;

    if (szam > 0)
    {
        cout << "A szam pozitiv." << endl;
    }
    else if (szam < 0)
    {
        cout << "A szam negativ." << endl;
    }
    else {
        cout << "A szam nulla." << endl;
    }

    return 0;
}
