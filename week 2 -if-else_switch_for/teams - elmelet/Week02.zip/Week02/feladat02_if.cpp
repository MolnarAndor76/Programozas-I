#include<iostream>
using namespace std;

int main()
{
	int szam;
	cout << "adajon meg egy egesz szamot ";
	cin >> szam;
	cout << "\nA megadott szam: " << szam << ", ";
	if (szam == 10)
	{
		cout << "egyenlo 10-zel";
	}
	else
	{
		if (szam < 10)
		{
			cout << "kisebb";
		}
		else
		{
			cout << "nagyobb";
		}
		cout << " mint 10";
	}
	cout << endl;
	return 0;
}

