#include<iostream>
using namespace std;

int main()
{
	int x, y, z;
	cout << "adaja meg a teglatest 1. elet(x) ";
	cin >> x;
	cout << "adaja meg a teglatest 2. elet(y) ";
	cin >> y;
	cout << "adaja meg a teglatest 3. elet(z) ";
	cin >> z;
	system("cls");
	cout << "A teglatest felszine, terfogata\n";
	cout << "\nelek: x = " << x << "  y = " << y << "  z = " << z << endl;
	cout << "\nA = 2*(x*y + y*z + x*z) = 2*(" << x << "*" << y << " + " << y << "*" << z
		<< " + " << x << "*" << z << ") = " << 2 * (x * y + y * z + x * z) << endl;
	cout << "\nV = x*y*z = " << x << "*" << y << "*" << z << " = " << x * y * z << endl;
	return 0;
}

