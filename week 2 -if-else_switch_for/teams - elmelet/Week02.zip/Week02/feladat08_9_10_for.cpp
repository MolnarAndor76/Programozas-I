#include<iostream>
using namespace std;

int main()
{
	setlocale(LC_ALL, "hu_HU.UTF-8"); //ékezetek kiíratáskor

	//írassuk ki az egész számok összegét [1;100], 
	int i, ossz = 0;
	for (i = 1; i < 101; i++)
	{
		ossz += i; 	//ossz=ossz+i; - röviden
	}
	cout << "összeg(for): " << ossz << endl;

	//írassuk ki a  páros egész számokat 10-től 0-ig
	int n;
	for (n = 10; n >= 0; n = n - 2)
	{
		cout << n << "  ";
	}
	cout << endl;

	//kérjünk be egy alsó határt E[1;50] és egy felső határt
	//E[100;200] - egész számok - és írsassuk ki az összeget!
	//minta:
	//összeg[1; 100]: 5050
	int ah, fh;
	do
	{
		cout << "kérem az alsó határt[1;50]: ";
		cin >> ah;
	} while (ah < 1 || ah>50);
	do
	{
		cout << "kérem a felső határt[100;200]: ";
		cin >> fh;
	} while (fh < 100 or fh>200);
	int osszeg = 0;
	int o;
	for (o = ah; o <= fh; o++)
	{
		osszeg += o;
	}
	cout << "összeg[" << ah << ";" << fh << "]: " << osszeg << endl;

	return 0;
}