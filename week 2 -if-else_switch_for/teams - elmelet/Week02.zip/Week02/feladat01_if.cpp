#include<iostream>
using namespace std;

int main()
{
	setlocale(LC_ALL, "hu_HU.UTF-8"); //ékezetek kiíratáskor
	int szam;
	cout << "adajon meg egy egesz szamot ";
	cin >> szam;
	cout << "\nA megadott szam:" << szam;
	if (szam % 2 == 0)
	{
		cout << " páros";
	}
	else
	{
		cout << " páratlan";
	}
	cout << endl;
	return 0;
}

