#include <iostream>
#include<string>  
using namespace std;

int main()
{
    //Írjunk programot, amely bekér egy stringet(max. 1 soros) lehet benne szóköz is
    //és kiszámítja a magánhangzók, mássalhangzók, számjegyek és 
    //az egyéb(az előző 3 kategóriába nem tartozó) karakterek számát.
    //Megj:
    //az egyebet nem számoljuk: a string hosszából - length() - kivonjuk a magánhangzók, 
    //a mássalhangzók és a számjegyek számának összegét
  
    setlocale(LC_ALL, "hu_HU.UTF-8"); //ékezetek kiíratáskor
    string szoveg;
    int magan = 0, massal = 0, szam = 0, egyeb;
    cout << "Adjon meg egy maximum egy sor hosszúságú stringet: ";
    getline(cin, szoveg);   //getline kell a cin csak az első szóközig olvas
    int hossz = szoveg.length();

    for (int i = 0; i < hossz; ++i)
    {
        //Hf: bővítsük magyar ékezetesekre is
        if (szoveg[i] == 'a' or szoveg[i] == 'e' or szoveg[i] == 'i' or   
            szoveg[i] == 'o' or szoveg[i] == 'u' or szoveg[i] == 'A' or
            szoveg[i] == 'E' or szoveg[i] == 'I' or szoveg[i] == 'O' or
            szoveg[i] == 'U')
        {
            ++magan;
        }
        else
        {   //kihasználjuk az autómatikus konverzót: szoveg[i]='a' esetén a szöveg[i] értéke 61 lesz (ASCII kód)
            //valamint azt, hogy a kisbetűk és nagybetűk is egymásután helyezkednek az ASCII kódtáblában
            //int szsz = szoveg[i];  //teszt az automatikus konverzióra
            if ((szoveg[i] >= 'a' and szoveg[i] <= 'z') or (szoveg[i] >= 'A' and szoveg[i] <= 'Z'))
            {
                //cout << szsz << endl;  //teszt az automatikus konverzióra
                ++massal;
            }
            else
            {
                if (szoveg[i] >= '0' and szoveg[i] <= '9')
                {
                    szam++;
                }
            }
        }
    }
    egyeb = hossz - (magan + massal + szam);
    cout << "A szöveg hossza: " << hossz << " karakter" << endl;
    cout << "Magánhangzók száma: " << magan << endl;
    cout << "Mássalhangzók száma: " << massal << endl;
    cout << "Számok száma: " << szam << endl;
    cout << "Egyéb karakterek száma: " << egyeb << endl;
    cout << "Ellnőrzés: " << magan << " + " << massal << " + " << szam << " + " << egyeb << " = "
        << magan + massal + szam + egyeb << " <- ha ez az összeg megegyezik a szöveg hosszával, akkor OK"<<endl;

    return 0;
}
