#include <iostream>
#include <string>
using namespace std;

int main()
{
    //Írjunk programot, amely bekér egy osztályzatot[1;5] és ezt kiírja betűvel(elégtelen ... stb.)
    //Megj.
    //a feladat megoldható egymásba ágyazott if-ekkel, de most switch-el oldjuk meg
    //Hf-nek megoldhatják if-fel is
    setlocale(LC_ALL, "hu_HU.UTF-8"); //ékezetek kiíratáskor
    int jegy;
    cout << "Adjon meg egy osztályzatot[1;5]: ";
    cin >> jegy;
    switch (jegy)
    {
    case 1: cout << "elégtelen" << endl; break;
    case 2: cout << "elégséges" << endl; break;
    case 3: cout << "közepes" << endl; break;
    case 4: cout << "jó" << endl; break;
    case 5: cout << "jeles" << endl; break;
    default: cout << "érvénytelen osztályzat" << endl;
    }
    return 0;
}