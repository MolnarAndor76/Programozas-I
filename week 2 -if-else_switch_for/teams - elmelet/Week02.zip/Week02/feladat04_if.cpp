
#include <iostream>
using namespace std;

int main() 
{
    //szökőév 
    //Szökőév az az év, amely osztható 4-gyel, de nem osztható 100-zal, kivéve, ha osztható 400-zal is.)
    //év bekérés ellenőtzötten [1;3000]
    setlocale(LC_ALL, "hu_HU.UTF-8"); //ékezetek kiíratáskor
    int ev;
    do
    {
        cout << "Adjon meg egy évszamot[1;3000]: ";
        cin >> ev;
    } while (ev < 1 or ev > 3000);
    if ((ev % 4 == 0 and ev % 100 != 0) || (ev % 400 == 0)) //mert ha osztható 400-zal, akkor 4-gyel is
    {
        cout << ev << " év szökőév." << endl;
    }
    else {
        cout << ev << " év nem szökőév." << endl;
    }

    return 0;
}
