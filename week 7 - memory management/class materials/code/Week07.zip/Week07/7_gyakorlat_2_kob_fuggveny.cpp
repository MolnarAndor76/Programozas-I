#include<iostream>
using namespace std;
int kob(int x);			// f�ggv�ny deklar�ci�ja
int main()
	{
	int szam1;
	cout<<"adjon meg egy szamot !";
	cin>>szam1;
	cout <<"\n a szam kobe "<<kob(szam1); // f�ggv�nyh�v�s �tadjuk a form�lis param�ter �rt�k�t
	system("pause");
	return 0;
    }
int kob(int x) // f�ggv�ny defin�ci�ja
	{
	return x*x*x; 
	}
