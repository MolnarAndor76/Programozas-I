#include <iostream>
using namespace std;
double fakt(int ); // C++-ban nem k�telez� megadni a v�ltoz� nev�t
int main()
{
      int szam;
      cout<<"\nAdjon meg egy szamot\n";
      cin>>szam;
      cout<<"A szam faktorialisa : "<<fakt(szam)<<endl;
    system("PAUSE");
    return EXIT_SUCCESS;  //return 0
}
double fakt(int x)
{
       double szorzat=1;
	   for (int i = 2; i <= x; i++)
		   szorzat = szorzat*i;
return szorzat;
}
