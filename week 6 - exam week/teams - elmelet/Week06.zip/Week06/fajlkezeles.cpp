#include <iostream>
#include <fstream>
#include <string>
#include <ctime>
using namespace std;
struct Tanulo
{
    string nev;
    int magas;
};

int main()
{
    Tanulo csoport[12], csop[12];
    srand(time(0));
    for (int i = 0; i < 12; i++)
    {
        cout << i + 1 << ". tanulo neve: ";
        getline(cin, csoport[i].nev);
        csoport[i].magas = rand() % 71 + 140;
    }
    ofstream ki("tanulok.txt");     // Kiírás fájlba
    if (!ki.is_open())
    {
        cout << "A fajl nem nyithato meg!" << endl;
        return 1;
    }

    for (int i = 0; i < 12; i++)
    {
        ki << csoport[i].nev << ";" << csoport[i].magas << endl;
    }
    ki.close();
    cout << "Az adatok sikeresen kimentve a tanulok.txt fajlba." << endl;
    ifstream vissza("tanulok.txt");     // beolvasás fájlból
    for (int i = 0; i < 12; i++)
    {
        getline(vissza, csop[i].nev, ';');
        vissza >> csop[i].magas;
        cout << i+1<<". "<< csop[i].nev << " - " << csop[i].magas << " cm magas.";
    }
    return 0;
}
