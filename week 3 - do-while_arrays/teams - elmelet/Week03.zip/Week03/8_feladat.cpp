//Egy csoportba max 15-en j�rhatnak. K�rj�k be egyenk�nt a csoport mat jegyeit(1-5) 
//�s t�roljuk egy JEGY[] t�mbben. Minden bek�r�s ut�n k�rdezz�k meg van-e m�g adat (Y)
// �rassuk ki t�bl�zatos form�ban a jegyeket egy �j ciklussal
// �s sz�m�tsuk ki a csoport �tlag�t! 

#include <iostream>
using namespace std;

int main()
{
	int JEGY[15], atl = 0, i, letszam = 0;
	char betu;
	do
	{
		do
		{
			cout << "Adja meg a(z) " << letszam + 1 << ". tanulo jegyet: ";
			cin >> JEGY[letszam];
		} while (JEGY[letszam] < 1 || JEGY[letszam]>5);
		cout << "Van meg adat ? (nyomjon 'y'-t ha igen): ";
		cin >> betu;
		letszam++;
	} while (betu == 'y' && letszam < 15);
	system("CLS");				// k�perny� t�rl�s
// t�mb elemeinek ki�rat�sa + �tlagsz�m�t�s
	for (i = 0;i < letszam;i++)
	{
		cout << "A(z) " << i + 1 << ". tanulo jegye \t" << JEGY[i] << endl;
		atl = atl + JEGY[i];
	}
	cout << "A csoport atlaga: " << (float)atl / letszam << endl;
	cout << endl;
	system("pause");
	return 0;
}
