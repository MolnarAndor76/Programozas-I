# include <iostream>			
using namespace std;
int main()
{
	int i;
	char betu = 'A';
	i = betu;
	cout << "Egy betu kiiratasa szamkent: " << i << ", karakterkent: " << betu <<endl;
	system("pause");
	return 0;
}
