// K�rj�nk be egy sz�mot �s d�nts�k el, hogy pr�m -e!
// Haszn�ljunk el�ltesztel� ciklust!
#include <iostream>
#include <cmath>	//a matematikai f�ggv�nyek szerepelnek ebben az �llom�nyban 
using namespace std;
int main()
{
	int i = 2, szam, x, osztoszam = 0;
	cout << "Adja meg a vizsgalando szamot: ";
	cin >> szam;
	x = sqrt(szam);	// sqrt <-a gy�k f�ggv�ny- van olyan k�rnyezet 	ahol a param�ter double kell hogy legyen					//
	while (i <= x && osztoszam == 0)	//a ciklus csak addig fut am�g meg nem tal�ljuk az
	{  						// els� oszt�t ill. el nem �r�nk a sz�m gy�k�ig
		if (szam%i == 0)
		{
			osztoszam++;
		}
		i++;
	}
	if (osztoszam > 0) 
	{
		cout << "Nem prim." <<endl;
	}
	else 
	{
		cout << "prim" <<endl;
	} 
	return 0;
}
