// t�lts�nk fel egy max 15 elem� t�mb�t ellen�rz�tten (0-100)
// �rassuk ki az elemeket t�bl�zatosan. Keress�k meg a max elem index�t, �rt�k�t!
//cser�lj�k meg a t�mbben a max elemet az els� elemmel 
// �rassuk ki �jra a t�mb�t! 

#include <iostream>
using namespace std;

int main()
{
	int tomb[15], maxindex = 0, maxertek, i, db, seged;
	do                                //ellen�rz�tt elemsz�m bek�r�s
	{
		cout << "Adja meg a tomb elemszamat (1-15): ";
		cin >> db;
	} while (db < 1 || db>15);
	cout << endl;
	for (i = 0;i < db;i++)           //ellen�rz�tt adat bek�r�s
	{
		do
		{
			cout << "Adja meg a tomb " << i + 1 << ". elemet (0-100) ";
			cin >> tomb[i];
		} while (tomb[i] < 0 || tomb[i]>100);
	}
	cout << endl;

	for (i = 0;i < db;i++)               // t�mb elemeinek ki�rat�sa
	{
		cout << "A tomb  " << i + 1 << ". eleme \t" << tomb[i] << endl;
	}
	cout << endl;

	// maximum kiv�laszt�s
	for (i = 1;i < db;i++)
	{
		if (tomb[maxindex] < tomb[i])
		{
			maxindex = i;
		}

	}
	cout << endl << "A max elem indexe: " << maxindex;
	cout << endl << "A max elem erteke: " << tomb[maxindex] << endl;

	// elemcsere
	cout << "Elemcsere utan: " << endl;
	seged = tomb[0];
	tomb[0] = tomb[maxindex];
	tomb[maxindex] = seged;

	// ki�rat�s elemcsere ut�n
	for (i = 0;i < db;i++)
	{
		cout << "A tomb  " << i + 1 << ". eleme \t" << tomb[i] << endl;
	}

	system("pause");
	return 0;
}
