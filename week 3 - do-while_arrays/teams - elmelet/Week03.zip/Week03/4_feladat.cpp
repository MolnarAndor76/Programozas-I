// P�lda ellen�rz�tt adatbek�r�sre. K�rj�nk be k�t sz�mot 0 �s 100 k�z�tt!
// Sz�m�tsuk ki az �sszeg�ket, k�l�nbs�g�ket �s szorzatukat!
#include <iostream>			
using namespace std;
int main()
{
	int szam1, szam2;
	do
	{
		cout << "Adjon meg egy szamot 0 es 100 kozott: ";
		cin >> szam1;
		cout << "Adjon meg egy masik szamot szinten 0 es 100 kozott: ";
		cin >> szam2;
		if (szam1 > 100 || szam1 < 0 || szam2>100 || szam2 < 0)
		{
			cout << "Valamelyik szam nem esik 0 �s 100 koze"<<endl;
		}
	} while (szam1>100 || szam1<0 || szam2>100 || szam2<0);

	cout << "osszeguk : " << szam1 + szam2 << endl;
	cout << "kulonbseguk : " << szam1 - szam2 << endl;
	cout << "szorzatuk : " << szam1*szam2 << endl;
	return 0;
}
