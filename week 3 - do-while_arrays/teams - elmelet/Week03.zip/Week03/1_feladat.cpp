// K�rj�nk be egy sz�mot �a billenty�zetr�l majd sz�moljuk ki az 
// eg�sz sz�mok �sszeg�t 1-t�l a sz�mig !
// Haszn�ljunk el�ltesztel� ciklust!
#include <iostream>
using namespace std;
int main()
{
	int i=1, szam, ossz=0;
	cout << "Adjon meg egy szamot: ";
	cin >> szam;
	while (i <=szam)	
	{  						
		ossz = ossz + i;
		i++;
	}
	cout << "A szamok osszege: "<<ossz <<endl; 
	return 0;
}
