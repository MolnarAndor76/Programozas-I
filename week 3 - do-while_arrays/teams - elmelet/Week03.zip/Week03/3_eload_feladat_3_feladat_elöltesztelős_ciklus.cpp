#include <iostream>			
using namespace std;
int main()
{
	//int i=0;
	//while (i < 10)                     		 // vigy�zz itt nincs a sor v�g�n ; 
	//{
	//	cout << "Geza kek az eg\n";
	//	i++;
	//}
	////cout << i;

	int a = 10, b = 5;
	cout<<a - ++b + a % 9;

	system("pause");
	return 0;
}
