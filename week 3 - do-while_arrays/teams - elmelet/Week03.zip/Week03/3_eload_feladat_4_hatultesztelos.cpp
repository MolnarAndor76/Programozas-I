#include <iostream>			
using namespace std;
int main()
{
	int i = 0;
	do
	{
		cout << "Geza kek az eg\n";
		i++;
	}
	while(i < 10);
	//cout << i;
	system("pause");
	return 0;
}
