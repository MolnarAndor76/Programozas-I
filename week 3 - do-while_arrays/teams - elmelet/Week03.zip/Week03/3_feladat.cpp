/*p�lda do {} while ciklusra.K�rj�k be ellen�rz�tten egy Zh pontsz�m�t(0 100) �s �rjuk ki, 
//hogy megfelelt -e ( pont<51 ) vagy sem! */
#include <iostream>			
using namespace std;
int main()
{
	int szam;
	do
	{
		cout << "Adjon meg egy szamot 0 es 100 kozott: ";
		cin >> szam;
		
	} 
	while (szam<0|| szam>100); 	//  addig fut �jra a ciklus am�g a sz�m nem esik 0-100-ig 
	
	if (szam < 51) 
	{
		cout << "Mebukott." << endl;
	}
	else 
	{
		cout << "Megfelelt." << endl;
	}
	return 0;
}
