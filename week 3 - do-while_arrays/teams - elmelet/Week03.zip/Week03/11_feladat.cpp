#include <iostream>			
using namespace std;
//K�sz�ts�k el az ASCII k�dt�bl�t!
int main()
{
	int i;
	char bet;
	cout << "Az ASCII kodtabla: " << endl;
	for (i = 0; i <= 255; i++)
	{
		bet = i;
		cout << i << " = " << bet << "\t";
	}
	return 0;
}
