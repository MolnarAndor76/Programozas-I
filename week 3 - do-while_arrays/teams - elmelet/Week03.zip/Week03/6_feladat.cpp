// Egy tanul�csoportba 8 tanul� tanult informatik�t.
// K�rj�k be a tanul�k jegyeit (1-5), t�roljuk azokat a JEGY[] t�mbben!
// Sz�m�tsuk ki a csoport �tlag�t!
#include <iostream>
using namespace std;
int main()
{
	int JEGY[8], i,ossz=0;
	for (i = 0; i<8; i++)
	{
		cout << "Adja meg az " << i + 1 << " . tanulo jegyet " << endl;
		cin >> JEGY[i];
	}
	for (i = 0; i < 8; i++)
	{
		ossz = ossz + JEGY[i];
	}
	cout << "A csoport tanulmanyi atlaga: " <<(float)ossz/i << endl;
	return 0;
}
