/* P�lda a switch - case haszn�lat�ra.Pr�b�ljuk ki az �gakat break - kel �s ann�lk�l is! */
#include <iostream>			
using namespace std;
int main()
{
	int jegy;
	do
	{
		cout << "Adja meg a matematika jegyet: ";
		cin >> jegy;
	} while (jegy<1 || jegy>5);
	switch (jegy)
	{
		case 1: cout << "elegtelen"; break;
		case 2: cout << "elegseges"; break;
		case 3: cout << "kozepes"; 	break;
		case 4: cout << "jo"; break;
		case 5: cout << "jeles";break;
	}
	cout << endl;
	return 0;
}
