// Kock�val dobunk 8-szor(1-6) t�lts�k az egyes dob�sok eredm�ny�t a kocka[] t�mbbe.
// Sz�moljuk meg hogy az egyes dob�sokb�l h�ny db volt ( MEGSZ�ML�L�S t�tele) �s �rassuk ki!
// Az egyes dob�sok eredm�ny�t billenty�zetr�l k�rj�k be!
// sz�moljuk meg h�ny db p�ros dob�s volt!
#include <iostream>
using namespace std;
int main()
{
	int kocka[8], TAR[6] = { 0 }, i; // A TAR[] -ban sz�moljuk, hogy az egyes dob�sokb�l mennyi volt
	//ellen�rz�tt dob�s bek�r�s
	for (i = 0;i < 8;i++)           
	{
		do
		{
			cout << "Adja meg az " << i + 1 << ". dobas eredmenyet ";
			cin >> kocka[i];
		} while (kocka[i] < 1 || kocka[i]>6);
	}

	int dbparos = 0;
	// eredm�nyek megsz�ml�l�sa, p�ros dob�sok sz�ma 
	for (i = 0;i < 8;i++)              
	{
		switch (kocka[i])
		{
		case 1:	TAR[0]++; break;
		case 2: TAR[1]++; break;
		case 3: TAR[2]++; break;
		case 4: TAR[3]++; break;
		case 5: TAR[4]++; break;
		case 6: TAR[5]++; break;
		}
		if (kocka[i] % 2 == 0)
		{
			dbparos++;
		}
	}
	// eredm�nyek ki�rat�sa         
	cout << endl;
	for (i = 0;i < 6;i++)                  
	{
		cout << "\nA(z) " << i + 1 << "-es dobasok szama:\t" << TAR[i];
	}
	cout << endl;
	cout << "\nA(z) paros dobasok szama:\t" << dbparos<<endl;
	return 0;
}
