# include <iostream>			
using namespace std;
// P�lda karakterek haszn�lat�ra
int main()
{
	int i;
	char betu = 'A';
	i = betu;
	cout << "Egy betu kiiratasa szamkent: " << i << ", karakterkent: " << betu <<endl;
	return 0;
}
